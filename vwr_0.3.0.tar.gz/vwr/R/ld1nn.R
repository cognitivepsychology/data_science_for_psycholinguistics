ld1nn <-
function(...){
    return(ldknn(...))
}

